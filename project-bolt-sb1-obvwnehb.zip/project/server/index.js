import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 3001;

const VTEX_BASE = 'https://offcorss.myvtex.com/api/catalog_system/pub/products/search';

app.use(cors());

interface VtexImage {
  imageUrl: string;
  imageText: string;
}

interface VtexSeller {
  sellerId: string;
  sellerName: string;
  commertialOffer: {
    Price: number;
    ListPrice: number;
    AvailableQuantity: number;
    IsAvailable: boolean;
  };
}

interface VtexItem {
  itemId: string;
  name: string;
  nameComplete: string;
  images: VtexImage[];
  sellers: VtexSeller[];
  Talla?: string[];
  'Codigo de color'?: string[];
}

interface VtexProduct {
  productId: string;
  productName: string;
  brand: string;
  productTitle: string;
  linkText: string;
  categoryId: string;
  categories: string[];
  description: string;
  releaseDate: string;
  Color?: string[];
  items: VtexItem[];
}

interface NormalizedProduct {
  productId: string;
  itemId: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  listPrice: number;
  status: string;
  imageUrl: string;
  sizes: string[];
  colors: string[];
  description: string;
  stock: number;
  releaseDate: string;
  linkText: string;
  allImages: { url: string; text: string }[];
}

function deriveStatus(item: VtexItem): string {
  const offer = item.sellers?.[0]?.commertialOffer;
  if (!offer) return 'Inactivo';
  if (offer.AvailableQuantity > 0 && offer.IsAvailable) return 'Activo';
  if (offer.Price > 0 && offer.IsAvailable) return 'Activo';
  return 'Agotado';
}

function normalizeProduct(p: VtexProduct): NormalizedProduct | null {
  if (!p.items || p.items.length === 0) return null;

  const firstItem = p.items[0];
  const offer = firstItem.sellers?.[0]?.commertialOffer;

  const imageUrl =
    firstItem.images?.[0]?.imageUrl ||
    'https://offcorss.vteximg.com.br/arquivos/ids/797552/logo-offcorss-producto.jpg';

  const categoryRaw = p.categories?.[0] || '';
  const parts = categoryRaw.split('/').filter(Boolean);
  const category = parts.length > 0 ? parts[parts.length - 1] : 'Sin categoría';

  const sizes = [
    ...new Set(
      p.items
        .flatMap((item) => item.Talla || [])
        .filter(Boolean),
    ),
  ];

  const colors = p.Color || firstItem['Codigo de color'] || [];

  const allImages = (firstItem.images || []).map((img) => ({
    url: img.imageUrl,
    text: img.imageText || p.productName,
  }));

  return {
    productId: p.productId,
    itemId: firstItem.itemId,
    name: p.productName,
    brand: p.brand || 'OFFCORSS',
    category,
    price: offer?.Price ?? 0,
    listPrice: offer?.ListPrice ?? 0,
    status: deriveStatus(firstItem),
    imageUrl,
    sizes,
    colors,
    description: (p.description || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ''),
    stock: offer?.AvailableQuantity ?? 0,
    releaseDate: p.releaseDate || '',
    linkText: p.linkText || '',
    allImages,
  };
}

app.get('/api/products', async (req, res) => {
  try {
    const from = Math.max(0, parseInt(req.query._from as string) || 0);
    const to = Math.min(from + 49, parseInt(req.query._to as string) || from + 49);

    const url = `${VTEX_BASE}?_from=${from}&_to=${to}`;
    const response = await fetch(url, {
      headers: { Accept: 'application/json' },
    });

    if (!response.ok) {
      return res.status(response.status).json({
        error: `VTEX API responded with status ${response.status}`,
      });
    }

    const raw: VtexProduct[] = await response.json();
    const products = raw
      .map(normalizeProduct)
      .filter((p): p is NormalizedProduct => p !== null);

    const totalHeader = response.headers.get('resources') || '';
    const totalMatch = totalHeader.match(/\/(\d+)/);
    const total = totalMatch ? parseInt(totalMatch[1]) : products.length;

    res.json({ products, total, range: { from, to } });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    res.status(500).json({ error: `Failed to fetch VTEX products: ${message}` });
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'offcorss-vtex-proxy' });
});

app.listen(PORT, () => {
  console.log(`OFFCORSS VTEX proxy server running on http://localhost:${PORT}`);
});
