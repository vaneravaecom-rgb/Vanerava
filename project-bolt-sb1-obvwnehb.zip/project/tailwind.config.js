/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#fff0f5',
          100: '#ffe0eb',
          200: '#ffc1d8',
          300: '#ff9bbf',
          400: '#ff6ba0',
          500: '#f74282',
          600: '#e6276a',
          700: '#c41a54',
          800: '#a01648',
          900: '#841340',
        },
        accent: {
          50: '#fff8e8',
          100: '#fff0c4',
          200: '#ffe088',
          300: '#ffc94a',
          400: '#ffb31f',
          500: '#f59900',
          600: '#d97a00',
          700: '#b45a00',
          800: '#904400',
          900: '#753600',
        },
        sky2: {
          50: '#eff9ff',
          100: '#def2ff',
          200: '#b6e6ff',
          300: '#75d3ff',
          400: '#2cbeff',
          500: '#00a4ef',
          600: '#0084c9',
          700: '#006ba3',
          800: '#005a86',
          900: '#054b6f',
        },
        mint: {
          50: '#effdf5',
          100: '#d8fbe8',
          200: '#b4f5d3',
          300: '#7aebb0',
          400: '#38d984',
          500: '#12c067',
          600: '#069b52',
          700: '#037a43',
          800: '#046036',
          900: '#054e2d',
        },
      },
      fontFamily: {
        sans: ['Poppins', 'system-ui', 'sans-serif'],
        display: ['Baloo 2', 'Poppins', 'sans-serif'],
      },
      borderRadius: {
        xl: '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
      },
      boxShadow: {
        soft: '0 4px 24px -6px rgba(247, 66, 130, 0.12)',
        card: '0 2px 16px -4px rgba(0, 0, 0, 0.08)',
        float: '0 12px 40px -10px rgba(247, 66, 130, 0.25)',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.4s ease-out',
        'pop': 'pop 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pop: {
          '0%': { transform: 'scale(0.9)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};
