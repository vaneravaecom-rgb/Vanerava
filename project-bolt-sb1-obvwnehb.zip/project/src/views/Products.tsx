import { useMemo, useState } from 'react';
import {
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  Eye,
  X,
  SlidersHorizontal,
  Loader2,
  RefreshCw,
  AlertCircle,
  Cloud,
} from 'lucide-react';
import { useProducts } from '@/hooks/useProducts';
import { STATUSES } from '@/types';
import type { Product, ProductStatus } from '@/types';
import { exportProductsToCSV, formatCurrency } from '@/utils';

interface ProductsProps {
  onSelectProduct: (product: Product) => void;
}

const PAGE_SIZE = 8;

export function Products({ onSelectProduct }: ProductsProps) {
  const { products, total, loading, error, refetch } = useProducts(0, 99);

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('all');
  const [status, setStatus] = useState<ProductStatus | 'all'>('all');
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [showFilters, setShowFilters] = useState(false);

  const availableCategories = useMemo(
    () => [...new Set(products.map((p) => p.category))].sort(),
    [products],
  );

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.productId.toLowerCase().includes(search.toLowerCase()) ||
        p.itemId.toLowerCase().includes(search.toLowerCase()) ||
        p.brand.toLowerCase().includes(search.toLowerCase());
      const matchCat = category === 'all' || p.category === category;
      const matchStatus = status === 'all' || p.status === status;
      return matchSearch && matchCat && matchStatus;
    });
  }, [products, search, category, status]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const pageItems = filtered.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (pageItems.length > 0 && pageItems.every((p) => selected.has(p.productId))) {
      setSelected((prev) => {
        const next = new Set(prev);
        pageItems.forEach((p) => next.delete(p.productId));
        return next;
      });
    } else {
      setSelected((prev) => {
        const next = new Set(prev);
        pageItems.forEach((p) => next.add(p.productId));
        return next;
      });
    }
  };

  const selectedProducts = products.filter((p) => selected.has(p.productId));

  const handleExport = () => {
    const toExport = selectedProducts.length > 0 ? selectedProducts : filtered;
    exportProductsToCSV(toExport);
  };

  const resetFilters = () => {
    setSearch('');
    setCategory('all');
    setStatus('all');
    setPage(0);
  };

  const hasActiveFilters = search !== '' || category !== 'all' || status !== 'all';

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
        <Loader2 className="w-10 h-10 text-brand-400 animate-spin" />
        <p className="mt-4 text-gray-400 text-sm">Cargando productos desde VTEX...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="card p-8 text-center animate-fade-in">
        <AlertCircle className="w-12 h-12 text-accent-400 mx-auto" />
        <p className="mt-4 text-gray-600 font-600">No se pudieron cargar los productos</p>
        <p className="mt-1 text-sm text-gray-400">{error}</p>
        <button onClick={refetch} className="btn-primary mt-5">
          <RefreshCw className="w-4 h-4" />
          Reintentar
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Data source indicator */}
      <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-mint-50 border border-mint-100 text-mint-700 text-sm">
        <Cloud className="w-4 h-4 shrink-0" />
        <span>
          Catálogo en vivo desde VTEX · {products.length} productos cargados
          {total > products.length && ` de ${total.toLocaleString()} totales`}
        </span>
      </div>

      {/* Toolbar */}
      <div className="card p-4 lg:p-5 space-y-4">
        <div className="flex flex-col lg:flex-row gap-3 lg:items-center">
          <div className="flex items-center gap-2 px-4 py-2.5 bg-brand-50/50 rounded-xl border border-brand-100 flex-1">
            <Search className="w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              placeholder="Buscar por nombre, productId, itemId o marca..."
              className="bg-transparent border-none outline-none text-sm flex-1 placeholder:text-gray-400"
            />
            {search && (
              <button onClick={() => setSearch('')} className="text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`btn-ghost ${showFilters ? 'bg-brand-50 border-brand-200 text-brand-600' : ''}`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="hidden sm:inline">Filtros</span>
            </button>
            <button onClick={handleExport} className="btn-primary">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Exportar CSV</span>
              {selectedProducts.length > 0 && (
                <span className="ml-1 px-2 py-0.5 rounded-full bg-white/25 text-xs">
                  {selectedProducts.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="flex flex-wrap gap-3 pt-3 border-t border-gray-50 animate-slide-up">
            <select
              value={category}
              onChange={(e) => { setCategory(e.target.value); setPage(0); }}
              className="px-4 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none focus:border-brand-300 transition-colors"
            >
              <option value="all">Todas las categorías</option>
              {availableCategories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            <select
              value={status}
              onChange={(e) => { setStatus(e.target.value as ProductStatus | 'all'); setPage(0); }}
              className="px-4 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none focus:border-brand-300 transition-colors"
            >
              <option value="all">Todos los estados</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>

            {hasActiveFilters && (
              <button onClick={resetFilters} className="btn-ghost text-sm">
                <X className="w-4 h-4" />
                Limpiar filtros
              </button>
            )}

            <span className="ml-auto text-sm text-gray-400 self-center">
              {filtered.length} producto(s) · {selectedProducts.length} seleccionado(s)
            </span>
          </div>
        )}
      </div>

      {/* Product grid */}
      {pageItems.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-gray-400 text-lg">No se encontraron productos</p>
          <p className="text-gray-300 text-sm mt-1">Prueba con otros criterios de búsqueda</p>
        </div>
      ) : (
        <>
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100 bg-brand-50/30">
                    <th className="px-4 py-3 text-left">
                      <input
                        type="checkbox"
                        checked={pageItems.length > 0 && pageItems.every((p) => selected.has(p.productId))}
                        onChange={toggleSelectAll}
                        className="w-4 h-4 rounded accent-brand-500 cursor-pointer"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-600 text-gray-400 uppercase tracking-wider">Producto</th>
                    <th className="px-4 py-3 text-left text-xs font-600 text-gray-400 uppercase tracking-wider hidden md:table-cell">Categoría</th>
                    <th className="px-4 py-3 text-left text-xs font-600 text-gray-400 uppercase tracking-wider hidden lg:table-cell">productId</th>
                    <th className="px-4 py-3 text-left text-xs font-600 text-gray-400 uppercase tracking-wider hidden lg:table-cell">itemId</th>
                    <th className="px-4 py-3 text-right text-xs font-600 text-gray-400 uppercase tracking-wider">Precio</th>
                    <th className="px-4 py-3 text-center text-xs font-600 text-gray-400 uppercase tracking-wider">Estado</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {pageItems.map((p) => (
                    <tr
                      key={p.productId}
                      className="border-b border-gray-50 hover:bg-brand-50/20 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={selected.has(p.productId)}
                          onChange={() => toggleSelect(p.productId)}
                          className="w-4 h-4 rounded accent-brand-500 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.imageUrl}
                            alt={p.name}
                            className="w-12 h-12 rounded-xl object-cover shrink-0 ring-1 ring-gray-100"
                          />
                          <div className="min-w-0">
                            <p className="font-600 text-sm text-gray-700 truncate">{p.name}</p>
                            <p className="text-xs text-gray-400">{p.brand}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className="text-sm text-gray-500">{p.category}</span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <span className="text-xs font-mono text-gray-500 bg-gray-50 px-2 py-1 rounded-lg">{p.productId}</span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <span className="text-xs font-mono text-gray-500 bg-gray-50 px-2 py-1 rounded-lg">{p.itemId}</span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className="text-sm font-600 text-gray-700">{formatCurrency(p.price)}</span>
                        {p.listPrice > p.price && (
                          <p className="text-xs text-gray-300 line-through">{formatCurrency(p.listPrice)}</p>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-500 ${
                          p.status === 'Activo' ? 'bg-mint-100 text-mint-700' :
                          p.status === 'Agotado' ? 'bg-accent-100 text-accent-700' :
                          'bg-gray-100 text-gray-500'
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => onSelectProduct(p)}
                          className="p-2 rounded-lg hover:bg-brand-100 text-gray-400 hover:text-brand-600 transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-400">
                Página {page + 1} de {totalPages}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                  disabled={page === 0}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">Anterior</span>
                </button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => setPage(i)}
                    className={`w-9 h-9 rounded-xl text-sm font-500 transition-all ${
                      page === i
                        ? 'bg-brand-500 text-white shadow-soft'
                        : 'bg-white text-gray-500 hover:bg-brand-50 border border-gray-100'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
                <button
                  onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                  disabled={page === totalPages - 1}
                  className="btn-ghost disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <span className="hidden sm:inline">Siguiente</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
