import { useState } from 'react';
import { Mail, Phone, MapPin, Store, Shield, Check, Edit2, Save, X } from 'lucide-react';
import { DEMO_USER } from '@/types';

export function Profile() {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    name: DEMO_USER.name,
    email: DEMO_USER.email,
    phone: DEMO_USER.phone,
    location: DEMO_USER.location,
    store: DEMO_USER.store,
    role: DEMO_USER.role,
  });

  const handleSave = () => {
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleCancel = () => {
    setForm({
      name: DEMO_USER.name,
      email: DEMO_USER.email,
      phone: DEMO_USER.phone,
      location: DEMO_USER.location,
      store: DEMO_USER.store,
      role: DEMO_USER.role,
    });
    setEditing(false);
  };

  const fields: { key: keyof typeof form; label: string; icon: typeof Mail; type: string }[] = [
    { key: 'name', label: 'Nombre completo', icon: Edit2, type: 'text' },
    { key: 'email', label: 'Correo electrónico', icon: Mail, type: 'email' },
    { key: 'phone', label: 'Teléfono', icon: Phone, type: 'tel' },
    { key: 'location', label: 'Ubicación', icon: MapPin, type: 'text' },
    { key: 'store', label: 'Tienda', icon: Store, type: 'text' },
    { key: 'role', label: 'Rol', icon: Shield, type: 'text' },
  ];

  return (
    <div className="space-y-5 animate-fade-in max-w-4xl">
      {/* Profile header */}
      <div className="card overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-brand-400 via-brand-500 to-accent-400" />
        <div className="px-6 lg:px-8 pb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-14">
            <img
              src={DEMO_USER.avatarUrl}
              alt={form.name}
              className="w-24 h-24 rounded-3xl object-cover ring-4 ring-white shadow-float"
            />
            <div className="flex-1 pt-2">
              <h2 className="font-display font-700 text-xl text-gray-800">{form.name}</h2>
              <p className="text-sm text-gray-400">{form.role}</p>
            </div>
            <div className="flex gap-2 no-print">
              {!editing ? (
                <button onClick={() => setEditing(true)} className="btn-primary">
                  <Edit2 className="w-4 h-4" />
                  Editar perfil
                </button>
              ) : (
                <>
                  <button onClick={handleCancel} className="btn-ghost">
                    <X className="w-4 h-4" />
                    Cancelar
                  </button>
                  <button onClick={handleSave} className="btn-primary">
                    <Save className="w-4 h-4" />
                    Guardar
                  </button>
                </>
              )}
            </div>
          </div>
          {saved && (
            <div className="mt-4 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-mint-50 text-mint-700 text-sm animate-pop no-print">
              <Check className="w-4 h-4" />
              Perfil actualizado correctamente
            </div>
          )}
        </div>
      </div>

      {/* Profile fields */}
      <div className="card p-6 lg:p-8">
        <h3 className="font-display font-600 text-gray-700 mb-5">Información de la cuenta</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {fields.map((f) => {
            const Icon = f.icon;
            return (
              <div key={f.key}>
                <label className="flex items-center gap-1.5 text-sm text-gray-400 mb-1.5">
                  <Icon className="w-3.5 h-3.5" />
                  {f.label}
                </label>
                <input
                  type={f.type}
                  value={form[f.key]}
                  disabled={!editing}
                  onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                  className={`w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all ${
                    editing
                      ? 'border-brand-200 bg-white focus:border-brand-400 focus:ring-2 focus:ring-brand-100'
                      : 'border-gray-100 bg-gray-50/50 text-gray-600'
                  }`}
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Demo notice */}
      <div className="rounded-2xl bg-accent-50 border border-accent-100 p-4 text-sm text-accent-700 flex items-start gap-2 no-print">
        <Shield className="w-5 h-5 shrink-0 mt-0.5" />
        <p>
          <span className="font-600">Modo demostración:</span> La autenticación no está activa. Los cambios en el perfil se guardan solo en esta sesión y no se envían a ningún servidor.
        </p>
      </div>
    </div>
  );
}
