import { Package, TrendingUp, AlertCircle, CheckCircle2, Tag, Activity, Loader2, RefreshCw, Cloud } from 'lucide-react';
import { useProducts } from '@/hooks/useProducts';
import { formatCurrency, formatDate } from '@/utils';
import type { ViewKey } from '@/components/Sidebar';
import type { Product } from '@/types';

interface DashboardProps {
  onNavigate: (view: ViewKey) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { products, total, loading, error, refetch } = useProducts(0, 99);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
        <Loader2 className="w-10 h-10 text-brand-400 animate-spin" />
        <p className="mt-4 text-gray-400 text-sm">Cargando catálogo desde VTEX...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="card p-8 text-center animate-fade-in">
        <AlertCircle className="w-12 h-12 text-accent-400 mx-auto" />
        <p className="mt-4 text-gray-600 font-600">No se pudieron cargar los productos</p>
        <p className="mt-1 text-sm text-gray-400">{error}</p>
        <button onClick={refetch} className="btn-primary mt-5">
          <RefreshCw className="w-4 h-4" />
          Reintentar
        </button>
      </div>
    );
  }

  const active = products.filter((p) => p.status === 'Activo').length;
  const outOfStock = products.filter((p) => p.status === 'Agotado').length;
  const inactive = products.filter((p) => p.status === 'Inactivo').length;
  const totalStock = products.reduce((s, p) => s + p.stock, 0);
  const totalValue = products.reduce((s, p) => s + p.price * p.stock, 0);
  const categories = [...new Set(products.map((p) => p.category))];

  const stats = [
    {
      label: 'Total Productos',
      value: total > products.length ? total.toLocaleString() : products.length.toString(),
      sub: total > products.length ? `Mostrando ${products.length} de ${total}` : undefined,
      icon: Package,
      color: 'from-brand-400 to-brand-600',
    },
    {
      label: 'Productos Activos',
      value: active.toString(),
      icon: CheckCircle2,
      color: 'from-mint-400 to-mint-600',
    },
    {
      label: 'Sin Stock',
      value: outOfStock.toString(),
      icon: AlertCircle,
      color: 'from-accent-400 to-accent-600',
    },
    {
      label: 'Inactivos',
      value: inactive.toString(),
      icon: Tag,
      color: 'from-sky2-400 to-sky2-600',
    },
  ];

  const recent = [...products]
    .sort((a, b) => (b.releaseDate || '').localeCompare(a.releaseDate || ''))
    .slice(0, 5);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Data source indicator */}
      <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-mint-50 border border-mint-100 text-mint-700 text-sm">
        <Cloud className="w-4 h-4 shrink-0" />
        <span>Datos obtenidos en tiempo real desde la API pública de VTEX (offcorss.myvtex.com)</span>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="card p-5 flex items-center gap-4 hover:shadow-soft transition-shadow">
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${s.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-7 h-7 text-white" />
              </div>
              <div className="min-w-0">
                <p className="text-3xl font-display font-700 text-gray-800">{s.value}</p>
                <p className="text-sm text-gray-400 truncate">{s.label}</p>
                {s.sub && <p className="text-xs text-gray-300 truncate mt-0.5">{s.sub}</p>}
              </div>
            </div>
          );
        })}
      </div>

      {/* Secondary metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card p-5">
          <div className="flex items-center gap-2 text-gray-400 mb-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm font-500">Valor de Inventario</span>
          </div>
          <p className="text-2xl font-display font-700 text-gray-800">{formatCurrency(totalValue)}</p>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-2 text-gray-400 mb-2">
            <Package className="w-4 h-4" />
            <span className="text-sm font-500">Unidades en Stock</span>
          </div>
          <p className="text-2xl font-display font-700 text-gray-800">{totalStock.toLocaleString()}</p>
        </div>
        <div className="card p-5">
          <div className="flex items-center gap-2 text-gray-400 mb-2">
            <Tag className="w-4 h-4" />
            <span className="text-sm font-500">Categorías</span>
          </div>
          <p className="text-2xl font-display font-700 text-gray-800">{categories.length}</p>
        </div>
      </div>

      {/* Recent activity + category breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-brand-500" />
              <h3 className="font-display font-600 text-gray-700">Productos Recientes</h3>
            </div>
            <button
              onClick={() => onNavigate('products')}
              className="text-sm text-brand-500 hover:text-brand-600 font-500"
            >
              Ver todo →
            </button>
          </div>
          <div className="space-y-3">
            {recent.map((p: Product) => (
              <div key={p.productId} className="flex items-center gap-3 group cursor-pointer" onClick={() => onNavigate('products')}>
                <img src={p.imageUrl} alt={p.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-600 text-gray-700 truncate group-hover:text-brand-600 transition-colors">{p.name}</p>
                  <p className="text-xs text-gray-400">{p.productId} · {formatDate(p.releaseDate)}</p>
                </div>
                <span className={`text-xs px-2.5 py-1 rounded-full font-500 ${
                  p.status === 'Activo' ? 'bg-mint-100 text-mint-700' :
                  p.status === 'Agotado' ? 'bg-accent-100 text-accent-700' :
                  'bg-gray-100 text-gray-500'
                }`}>
                  {p.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-display font-600 text-gray-700 mb-4">Productos por Categoría</h3>
          <div className="space-y-3">
            {categories.map((cat) => {
              const count = products.filter((p) => p.category === cat).length;
              const pct = products.length > 0 ? Math.round((count / products.length) * 100) : 0;
              return (
                <div key={cat}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-500 text-gray-600">{cat}</span>
                    <span className="text-gray-400">{count}</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-gray-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-brand-400 to-brand-500 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
