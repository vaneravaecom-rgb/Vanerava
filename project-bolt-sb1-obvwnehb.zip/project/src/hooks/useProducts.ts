import { useState, useEffect, useCallback } from 'react';
import type { Product, ProductsResponse } from '@/types';

interface UseProductsState {
  products: Product[];
  total: number;
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

const API_URL = '/api/products';

export function useProducts(from: number = 0, to: number = 99): UseProductsState {
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refetchFlag, setRefetchFlag] = useState(0);

  const refetch = useCallback(() => setRefetchFlag((f) => f + 1), []);

  useEffect(() => {
    let cancelled = false;

    async function fetchProducts() {
      setLoading(true);
      setError(null);

      try {
        const response = await fetch(`${API_URL}?_from=${from}&_to=${to}`, {
          headers: { Accept: 'application/json' },
        });

        if (!response.ok) {
          throw new Error(`Error del servidor (${response.status})`);
        }

        const data: ProductsResponse = await response.json();

        if (!cancelled) {
          setProducts(data.products);
          setTotal(data.total);
        }
      } catch (err) {
        if (!cancelled) {
          const message = err instanceof Error ? err.message : 'Error desconocido';
          setError(message);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchProducts();

    return () => {
      cancelled = true;
    };
  }, [from, to, refetchFlag]);

  return { products, total, loading, error, refetch };
}
