import { useState } from 'react';
import { Sidebar } from '@/components/Sidebar';
import type { ViewKey } from '@/components/Sidebar';
import { Topbar } from '@/components/Topbar';
import { Dashboard } from '@/views/Dashboard';
import { Products } from '@/views/Products';
import { ProductDetail } from '@/views/ProductDetail';
import { Profile } from '@/views/Profile';
import type { Product } from '@/types';

const TITLES: Record<ViewKey, string> = {
  dashboard: 'Dashboard',
  products: 'Catálogo de Productos',
  profile: 'Mi Perfil',
};

function App() {
  const [view, setView] = useState<ViewKey>('dashboard');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const handleNavigate = (v: ViewKey) => {
    setView(v);
    setSelectedProduct(null);
  };

  const renderContent = () => {
    if (view === 'products' && selectedProduct) {
      return <ProductDetail product={selectedProduct} onBack={() => setSelectedProduct(null)} />;
    }
    switch (view) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'products':
        return <Products onSelectProduct={setSelectedProduct} />;
      case 'profile':
        return <Profile />;
    }
  };

  const title = view === 'products' && selectedProduct ? 'Detalle del Producto' : TITLES[view];

  return (
    <div className="min-h-screen flex bg-brand-50/30">
      <Sidebar
        current={view}
        onNavigate={handleNavigate}
        mobileOpen={mobileNavOpen}
        onCloseMobile={() => setMobileNavOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title={title}
          onOpenMobile={() => setMobileNavOpen(true)}
          onNavigate={handleNavigate}
        />
        <main className="flex-1 p-4 lg:p-8 overflow-x-hidden">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;
