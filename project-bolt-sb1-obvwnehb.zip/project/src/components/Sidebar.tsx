import { LayoutDashboard, Package, User, Sparkles } from 'lucide-react';

export type ViewKey = 'dashboard' | 'products' | 'profile';

interface SidebarProps {
  current: ViewKey;
  onNavigate: (view: ViewKey) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const navItems: { key: ViewKey; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'products', label: 'Productos', icon: Package },
  { key: 'profile', label: 'Mi perfil', icon: User },
];

export function Sidebar({ current, onNavigate, mobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-30 lg:hidden"
          onClick={onCloseMobile}
        />
      )}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-72 bg-white border-r border-gray-100 z-40 transition-transform duration-300 flex flex-col ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex items-center gap-3 px-6 py-6 border-b border-gray-50">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center shadow-soft">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="font-display font-700 text-lg text-gray-800 leading-none">OFFCORSS</p>
            <p className="text-xs text-gray-400 mt-1">Panel Admin</p>
          </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = current === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  onNavigate(item.key);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
                  active
                    ? 'bg-brand-500 text-white shadow-soft'
                    : 'text-gray-500 hover:bg-brand-50 hover:text-brand-600'
                }`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
                {active && <span className="ml-auto w-2 h-2 rounded-full bg-white/80" />}
              </button>
            );
          })}
        </nav>

        <div className="px-6 py-5 border-t border-gray-50">
          <div className="rounded-2xl bg-gradient-to-br from-mint-50 to-brand-50 p-4">
            <p className="font-display font-600 text-sm text-gray-700">VTEX conectado</p>
            <p className="text-xs text-gray-400 mt-1">
              Catálogo en vivo desde la API pública de OFFCORSS. El perfil sigue en modo demostración.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
