import { Search, Menu, Bell } from 'lucide-react';
import { DEMO_USER } from '@/types';
import type { ViewKey } from '@/components/Sidebar';

interface TopbarProps {
  title: string;
  onOpenMobile: () => void;
  onNavigate: (view: ViewKey) => void;
}

export function Topbar({ title, onOpenMobile, onNavigate }: TopbarProps) {
  return (
    <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-gray-100 px-4 lg:px-8 py-4 flex items-center gap-4">
      <button
        onClick={onOpenMobile}
        className="lg:hidden p-2 rounded-xl hover:bg-brand-50 transition-colors"
      >
        <Menu className="w-5 h-5 text-gray-600" />
      </button>

      <div className="flex-1 min-w-0">
        <h1 className="font-display font-700 text-xl text-gray-800 truncate">{title}</h1>
      </div>

      <div className="hidden md:flex items-center gap-2 px-4 py-2.5 bg-brand-50/50 rounded-xl border border-brand-100 w-64 lg:w-80">
        <Search className="w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder="Buscar..."
          className="bg-transparent border-none outline-none text-sm flex-1 placeholder:text-gray-400"
        />
      </div>

      <button className="relative p-2.5 rounded-xl hover:bg-brand-50 transition-colors">
        <Bell className="w-5 h-5 text-gray-500" />
        <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-brand-500" />
      </button>

      <button
        onClick={() => onNavigate('profile')}
        className="flex items-center gap-3 pl-2 pr-3 py-1.5 rounded-xl hover:bg-brand-50 transition-colors"
      >
        <img
          src={DEMO_USER.avatarUrl}
          alt="avatar"
          className="w-9 h-9 rounded-xl object-cover ring-2 ring-brand-200"
        />
        <div className="hidden sm:block text-left">
          <p className="text-sm font-600 text-gray-700 leading-none">{DEMO_USER.name}</p>
          <p className="text-xs text-gray-400 mt-1">{DEMO_USER.role}</p>
        </div>
      </button>
    </header>
  );
}
